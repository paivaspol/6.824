
for i in {1..500}
do
	go test >> repeat_test_output;
done;
